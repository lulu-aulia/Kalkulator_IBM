document.getElementById("bmiForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const berat = parseFloat(document.getElementById("berat").value);
  const tinggi = parseFloat(document.getElementById("tinggi").value) / 100;

  const bmi = berat / (tinggi * tinggi);
  let status = "";
  let tips = "";

  if (bmi < 18.5) {
    status = "💡 Kurus";
    tips = `
      <ul>
        <li>🍚 Tambahkan porsi karbo dan protein sehat</li>
        <li>💪 Latihan otot ringan (angkat beban, yoga)</li>
        <li>🛌 Tidur 7–9 jam, teratur</li>
      </ul>
    `;
  } else if (bmi >= 18.5 && bmi < 25) {
    status = "✅ Ideal";
    tips = `
      <ul>
        <li>🥗 Jaga pola makan seimbang</li>
        <li>🏃‍♀️ Olahraga rutin 3–5 kali/minggu</li>
        <li>💧 Minum air putih cukup</li>
      </ul>
    `;
  } else if (bmi >= 25 && bmi < 30) {
    status = "⚠️ Gemuk";
    tips = `
      <ul>
        <li>🥦 Perbanyak sayur, kurangi nasi putih</li>
        <li>🧘 Olahraga kardio dan stretching</li>
        <li>🚫 Kurangi makanan berminyak/manis</li>
      </ul>
    `;
  } else {
    status = "🚨 Obesitas";
    tips = `
      <ul>
        <li>🥗 Konsultasikan pola makan ke ahli gizi</li>
        <li>🚶‍♂️ Mulai rutin aktivitas ringan setiap hari</li>
        <li>🥤 Ganti minuman manis dengan air putih</li>
        <li>🛌 Perbaiki jam tidur dan kurangi stres</li>
      </ul>
    `;
  }

  const hasil = `
    <p><strong>BMI kamu:</strong> ${bmi.toFixed(2)}</p>
    <p><strong>Status:</strong> ${status}</p>
    <p><strong>Tips Hidup Sehat:</strong></p>
    ${tips}
  `;

  document.getElementById("hasil").innerHTML = hasil;
});
