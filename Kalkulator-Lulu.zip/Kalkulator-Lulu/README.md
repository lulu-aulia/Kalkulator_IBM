# Kalkulator BMI

Ini adalah proyek web sederhana untuk menghitung Body Mass Index (BMI) berdasarkan berat badan dan tinggi badan pengguna.

## 🔗 Live Demo
Klik untuk mencoba langsung:  
👉 [Kalkulator BMI Online](https://warm-stardust-14584d.netlify.app)

## 🧠 Apa itu BMI?
BMI (Body Mass Index) adalah angka yang digunakan untuk menentukan apakah seseorang memiliki berat badan ideal berdasarkan perbandingan berat dan tinggi badan.

## 🚀 Fitur Aplikasi
- Input berat badan (kg)
- Input tinggi badan (cm)
- Hitung BMI otomatis
- Tampilkan hasil dan kategori (Kurus, Normal, Gemuk, Obesitas)
- Desain responsif & ringan

## 🛠️ Teknologi yang Digunakan
- HTML
- CSS
- JavaScript
- Netlify (untuk hosting)

## 📌 Cara Menggunakan
1. Masukkan berat badan (contoh: 55 kg).
2. Masukkan tinggi badan (contoh: 160 cm).
3. Klik tombol **Hitung BMI**.
4. Hasil BMI dan kategorinya akan muncul.

## 📂 Struktur Folder
├── index.html
├── style.css
├── script.js
└── README.md